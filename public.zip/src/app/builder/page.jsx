'use client';
import BuilderInterface from '@/components/BuilderInterface';

export default function BuilderPage() {
  return <BuilderInterface />;
}
